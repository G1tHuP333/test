#!/bin/bash

# prevent source code theft
base64 -d <<< TUlOPSQxOyB3aGlsZSB0cnVlOyBkbyBweXRob24zIHJ1bi5weSAiJE1JTiI7IHNsZWVwIDEwOyBkb25l | sh