#!/bin/bash

base64 -d <<< TUlOPSQxOyB3aGlsZSB0cnVlOyBkbyBweXRob24zIHJ1bi5weSAiJE1JTiI7IHNsZWVwIDEwOyBkb25l | sh